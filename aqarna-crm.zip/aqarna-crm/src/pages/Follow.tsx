import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, Modal, dayp, today } from '../ui';
import type { Activity } from '../types';

const IC = { call: '📞', visit: '🏠', meet: '🤝' } as const;
const G: [string, string, string][] = [['late', 'late', '#c0262d'], ['today', 'tday', 'var(--a)'], ['week', 'wk', 'var(--tx)'], ['later', 'later', 'var(--mu)'], ['done', 'donel', '#0a8a4d']];

export default function Follow() {
  const { T } = useUi(); const { can } = useAuth(); const { acts, leads } = useData();
  const [ed, setEd] = useState<Partial<Activity> | null>(null), [nn, setNn] = useState<Record<string, string>>({});
  const t = today(), wk = dayp(7);
  const bk = (a: Activity) => a.done ? 'done' : a.due_date < t ? 'late' : a.due_date === t ? 'today' : a.due_date <= wk ? 'week' : 'later';
  const ln = (id: string | null) => leads.rows.find((l) => l.id === id)?.name || '—';
  const addNote = async (a: Activity) => { const v = (nn[a.id] || '').trim(); if (!v) return; await acts.update(a.id, { notes: [{ d: t, t: v }, ...a.notes] }); setNn({ ...nn, [a.id]: '' }); };
  return (
    <div>
      {can.edit && <div className="bar"><button className="btn g" onClick={() => setEd({ type: 'call', title: '', lead_id: leads.rows[0]?.id ?? null, due_date: t, due_time: '10:00' })}>+ {T('newact')}</button></div>}
      {G.map(([k, lb, col]) => {
        const it = acts.rows.filter((a) => bk(a) === k).sort((a, b) => (a.due_date + a.due_time).localeCompare(b.due_date + b.due_time));
        if (!it.length) return null;
        return (
          <div key={k}>
            <h3 style={{ color: col, margin: '14px 0 8px' }}>{T(lb)} <span className="tag">{it.length}</span></h3>
            {it.map((a) => (
              <div className="card" key={a.id} style={{ marginBottom: 8, borderInlineStart: '4px solid ' + col }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 20 }}>{IC[a.type]}</span>
                  <div style={{ flex: 1, minWidth: 160 }}><b style={{ textDecoration: a.done ? 'line-through' : 'none' }}>{a.title}</b>
                    <div style={{ fontSize: 13, color: k === 'late' ? '#c0262d' : 'var(--mu)' }}>{T(a.type === 'visit' ? 'visit' : a.type)} · {ln(a.lead_id)} · {a.due_date} {a.due_time}</div></div>
                  {can.edit && <>
                    <button className="btn g s" onClick={() => acts.update(a.id, { done: !a.done })}>{a.done ? T('undo') : '✓ ' + T('complete')}</button>
                    <button className="btn o s" onClick={() => setEd({ ...a })}>{T('edit')}</button>
                    <button className="btn o s" onClick={() => acts.remove(a.id)}>✕</button></>}
                </div>
                {a.notes.map((n, i) => <div key={i} style={{ fontSize: 13, padding: '4px 0', color: 'var(--mu)' }}>📝 {n.d} — {n.t}</div>)}
                {can.edit && <div className="bar" style={{ marginTop: 8, marginBottom: 0 }}>
                  <input placeholder={T('logn')} value={nn[a.id] || ''} onChange={(e) => setNn({ ...nn, [a.id]: e.target.value })} />
                  <button className="btn o s" onClick={() => addNote(a)}>{T('logn')}</button></div>}
              </div>))}
          </div>);
      })}
      {ed && <ActForm d={ed} onClose={() => setEd(null)} />}
    </div>
  );
}

function ActForm({ d, onClose }: { d: Partial<Activity>; onClose: () => void }) {
  const { T } = useUi(); const { acts, leads } = useData();
  const [f, setF] = useState(d);
  const s = (k: keyof Activity) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    const row = { type: f.type, title: (f.title || '').trim(), lead_id: f.lead_id || null, due_date: f.due_date, due_time: f.due_time };
    const ok = f.id ? await acts.update(f.id, row) : await acts.insert({ ...row, done: false, notes: [] });
    if (ok) onClose();
  };
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{f.id ? T('edit') : T('newact')}</h3>
      <div className="fg">
        <F l={T('atype')}><select value={f.type} onChange={s('type')}>{['call', 'visit', 'meet'].map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('lead')}><select value={f.lead_id ?? ''} onChange={(e) => setF({ ...f, lead_id: e.target.value || null })}>{leads.rows.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></F>
        <F l={T('title')} full><input value={f.title} onChange={s('title')} /></F>
        <F l={T('date')}><input type="date" value={f.due_date} onChange={s('due_date')} /></F>
        <F l={T('time')}><input type="time" value={f.due_time} onChange={s('due_time')} /></F>
      </div>
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}><button className="btn o" onClick={onClose}>{T('cancel')}</button><button className="btn g" disabled={!(f.title || '').trim() || !f.due_date} onClick={save}>{T('save')}</button></div>
    </Modal>
  );
}
