import { useAuth, useData, useUi } from '../context';
import { dmonth, isOpen, today } from '../ui';

export default function Dashboard() {
  const { T, ar, money } = useUi(); const { can } = useAuth();
  const { leads, properties, deals, acts } = useData();
  const won = deals.rows.filter((d) => d.stage === 'won');
  const stats: [string, string | number][] = [
    [T('tl'), leads.rows.length], [T('th'), leads.rows.filter((l) => l.level === 'hot').length],
    [T('ta'), properties.rows.filter((p) => p.status === 'avail').length],
    [T('ts'), money(won.reduce((s, d) => s + d.value, 0))], [T('td'), deals.rows.filter((d) => isOpen(d.stage)).length],
  ];
  const months: string[] = [];
  for (let i = 5; i >= 0; i--) { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); months.push(d.toISOString().slice(0, 7)); }
  const vals = months.map((m) => won.filter((d) => dmonth(d) === m).reduce((s, d) => s + d.value, 0));
  const mx = Math.max(...vals, 1);
  const t = today();
  const due = acts.rows.filter((a) => !a.done && a.due_date <= t).sort((a, b) => a.due_date.localeCompare(b.due_date));
  return (
    <>
      <div className="grid">{stats.map(([l, v]) => <div className="card stat" key={l}><span style={{ color: 'var(--mu)' }}>{l}</span><b>{v}</b></div>)}</div>
      <div className="two">
        <div className="card"><b>{T('chart')}</b>
          <svg viewBox="0 0 420 190" style={{ width: '100%', marginTop: 8 }}>
            {vals.map((v, i) => { const h = v / mx * 130; return (
              <g key={i}>
                <rect x={i * 68 + 14} y={150 - h} width="40" height={h} rx="5" fill="var(--a)" />
                <text x={i * 68 + 34} y="170" textAnchor="middle" fontSize="12" fill="var(--mu)">{new Date(months[i] + '-01').toLocaleDateString(ar ? 'ar-SA' : 'en-US', { month: 'short' })}</text>
                <text x={i * 68 + 34} y={144 - h} textAnchor="middle" fontSize="10" fill="var(--tx)">{v ? (v / 1e6).toFixed(1) + 'M' : ''}</text>
              </g>); })}
          </svg>
        </div>
        <div className="card"><b>{T('today')}</b>
          {due.length === 0 && <div style={{ color: 'var(--mu)', marginTop: 8 }}>—</div>}
          {due.map((a) => (
            <div key={a.id} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '7px 0', borderBottom: '1px solid var(--bd)' }}>
              <input type="checkbox" style={{ width: 'auto' }} disabled={!can.edit} checked={a.done} onChange={() => acts.update(a.id, { done: true })} />
              <span style={{ flex: 1, color: a.due_date < t ? '#c0262d' : undefined }}>{a.title} · {a.due_time}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
