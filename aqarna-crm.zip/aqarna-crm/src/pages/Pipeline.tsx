import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, Modal, STG, today } from '../ui';
import type { Deal, Stage } from '../types';

export default function Pipeline() {
  const { T, ar, money } = useUi(); const { can } = useAuth();
  const { deals, leads, properties, brokers, bname, setStage } = useData();
  const [ed, setEd] = useState<Partial<Deal> | null>(null), [ov, setOv] = useState('');
  const ln = (id: string | null) => leads.rows.find((l) => l.id === id)?.name || '—';
  const pn = (id: string | null) => properties.rows.find((p) => p.id === id)?.no || '';
  const nx = ar ? '‹' : '›', pv = ar ? '›' : '‹';
  const save = async (f: Partial<Deal>) => {
    const row = { lead_id: f.lead_id, property_id: f.property_id || null, value: f.value, broker_id: f.broker_id, follow_date: f.follow_date };
    const r = f.id ? await deals.update(f.id, row) : await deals.insert({ ...row, stage: 'new' });
    if (r && f.property_id) {
      const p = properties.rows.find((x) => x.id === f.property_id);
      await properties.update(f.property_id, { lead_id: f.lead_id, deal_id: r.id, status: p?.status === 'avail' ? 'res' : p?.status });
    }
    if (r) setEd(null);
  };
  return (
    <div>
      {can.edit && <div className="bar"><button className="btn g" onClick={() => setEd({ lead_id: leads.rows[0]?.id ?? null, property_id: null, value: 0, broker_id: brokers[0]?.id ?? null, follow_date: today(), stage: 'new' })}>+ {T('newdeal')}</button></div>}
      <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 8, alignItems: 'flex-start' }}>
        {STG.map((st, i) => {
          const col = deals.rows.filter((d) => d.stage === st);
          return (
            <div key={st} className="card" style={{ flex: '0 0 220px', padding: 10, background: ov === st ? 'var(--bd)' : 'var(--sf)' }}
              onDragOver={(e) => { e.preventDefault(); setOv(st); }} onDragLeave={() => setOv('')}
              onDrop={(e) => { e.preventDefault(); setOv(''); const id = e.dataTransfer.getData('text'); if (can.edit && id) setStage(id, st as Stage); }}>
              <b style={{ color: st === 'won' ? '#0a8a4d' : st === 'lost' ? '#c0262d' : 'inherit' }}>{T('st_' + st)} <span className="tag">{col.length}</span></b>
              <div style={{ fontSize: 12, color: 'var(--mu)', margin: '2px 0 8px' }}>{money(col.reduce((s, d) => s + d.value, 0))}</div>
              {col.map((d) => (
                <div key={d.id} className="card" draggable={can.edit} onDragStart={(e) => e.dataTransfer.setData('text', d.id)} style={{ padding: 9, marginBottom: 8, fontSize: 13, cursor: can.edit ? 'grab' : 'default' }}>
                  <b>{ln(d.lead_id)}</b><div>{money(d.value)}</div>
                  <div style={{ color: 'var(--mu)' }}>{d.property_id ? pn(d.property_id) + ' · ' : ''}{bname(d.broker_id)}</div>
                  <div style={{ color: 'var(--mu)' }}>📅 {d.follow_date}</div>
                  {can.edit && <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                    <button className="btn o s" disabled={i === 0 || i === 7} onClick={() => setStage(d.id, STG[i - 1])}>{pv}</button>
                    <button className="btn o s" disabled={i >= 6} onClick={() => setStage(d.id, STG[i + 1])}>{nx}</button>
                    {i < 6 && <button className="btn o s" onClick={() => setStage(d.id, 'lost')}>✕</button>}
                    <button className="btn o s" onClick={() => setEd({ ...d })}>✎</button>
                  </div>}
                </div>))}
            </div>);
        })}
      </div>
      {ed && <DealForm d={ed} onClose={() => setEd(null)} onSave={save} />}
    </div>
  );
}

function DealForm({ d, onClose, onSave }: { d: Partial<Deal>; onClose: () => void; onSave: (f: Partial<Deal>) => void }) {
  const { T } = useUi(); const { leads, properties, brokers } = useData();
  const [f, setF] = useState(d); const won = f.stage === 'won';
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{f.id ? T('edit') : T('newdeal')}</h3>
      <div className="fg">
        <F l={T('lead')}><select value={f.lead_id ?? ''} onChange={(e) => setF({ ...f, lead_id: e.target.value || null })}>{leads.rows.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></F>
        <F l={T('prop')}><select disabled={won} value={f.property_id ?? ''} onChange={(e) => setF({ ...f, property_id: e.target.value || null })}><option value="">{T('none')}</option>
          {properties.rows.filter((p) => p.status === 'avail' || p.id === f.property_id).map((p) => <option key={p.id} value={p.id}>{p.no} · {p.project}</option>)}</select></F>
        <F l={T('value') + ' (SAR)'}><input type="number" disabled={won} value={f.value} onChange={(e) => setF({ ...f, value: +e.target.value })} /></F>
        <F l={T('bro')}><select value={f.broker_id ?? ''} onChange={(e) => setF({ ...f, broker_id: e.target.value || null })}>{brokers.map((b) => <option key={b.id} value={b.id}>{b.full_name}</option>)}</select></F>
        <F l={T('follow')}><input type="date" value={f.follow_date} onChange={(e) => setF({ ...f, follow_date: e.target.value })} /></F>
      </div>
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}><button className="btn o" onClick={onClose}>{T('cancel')}</button><button className="btn g" disabled={!((f.value || 0) > 0) || !f.broker_id} onClick={() => onSave(f)}>{T('save')}</button></div>
    </Modal>
  );
}
