import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, Modal, Splits, amt, today } from '../ui';
import type { Commission } from '../types';

type SP = { b: string; pct: number };

export default function Finance() {
  const { T, money } = useUi(); const { can, company } = useAuth(); const { comm, deals, leads, brokers, bname } = useData();
  const [fb, setFb] = useState(''), [ed, setEd] = useState<{ c: Commission; sp: SP[] } | null>(null);
  const [cv, setCv] = useState(2000000), [cr, setCr] = useState(company?.commission_rate ?? 2.5), [cc, setCc] = useState(company?.company_share ?? 40);
  const [sp, setSp] = useState<SP[]>(brokers.slice(0, 2).map((b, i, a) => ({ b: b.id, pct: a.length === 1 ? 100 : i === 0 ? 60 : 40 })));
  const lines = comm.rows.flatMap((c) => c.splits.map((s, i) => ({ c, s, i })));
  const vis = lines.filter((x) => !fb || x.s.b === fb);
  const sum = (st: string) => vis.filter((x) => x.s.status === st).reduce((a, x) => a + amt(x.c, x.s), 0);
  const tot = cv * cr / 100, pool = tot * (100 - cc) / 100;
  const toggle = (c: Commission, i: number) => comm.update(c.id, { splits: c.splits.map((s, j) => {
    if (j !== i) return s; const n = s.status === 'due' ? 'paid' : 'due'; return { ...s, status: n, log: [...s.log, { d: today(), s: n }] };
  }) });
  const dl = (id: string) => { const d = deals.rows.find((x) => x.id === id), l = d && leads.rows.find((x) => x.id === d.lead_id); return 'D-' + id.slice(0, 4) + (l ? ' · ' + l.name : ''); };
  const saveSp = async (c: Commission, ns: SP[]) => {
    const r = await comm.update(c.id, { splits: ns.map((n) => { const o = c.splits.find((s) => s.b === n.b); return { b: n.b, pct: n.pct, status: o?.status ?? 'due', log: o?.log ?? [{ d: today(), s: 'due' }] }; }) });
    if (r) setEd(null);
  };
  const stats: [string, number][] = [['total', comm.rows.reduce((a, c) => a + c.total, 0)], ['coAmt', comm.rows.reduce((a, c) => a + c.total * c.company_pct / 100, 0)], ['due', sum('due')], ['paid', sum('paid')]];
  return (
    <div>
      <div className="grid">{stats.map(([k, v]) => <div className="card stat" key={k}><span style={{ color: 'var(--mu)' }}>{T(k)}</span><b>{money(v)}</b></div>)}</div>
      <div className="card" style={{ marginBottom: 14 }}><b>{T('calc')}</b>
        <div className="fg" style={{ margin: '10px 0' }}>
          <F l={T('price') + ' (SAR)'}><input type="number" value={cv} onChange={(e) => setCv(+e.target.value)} /></F>
          <F l={T('rate')}><input type="number" step="0.1" value={cr} onChange={(e) => setCr(+e.target.value)} /></F>
          <F l={T('co')}><input type="number" value={cc} onChange={(e) => setCc(Math.min(100, +e.target.value))} /></F>
          <F l={T('br')}><input disabled value={100 - cc} /></F>
        </div>
        {brokers.length > 0 && <Splits sp={sp} setSp={setSp} brokers={brokers} />}
        <div style={{ marginTop: 10 }}>
          {([[T('total'), tot], [T('coAmt'), tot * cc / 100], [T('pool'), pool]] as [string, number][]).map(([l, v]) => <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}><span>{l}</span><b>{money(v)}</b></div>)}
          {sp.map((s, i) => <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: 'var(--mu)' }}><span>{bname(s.b)} ({s.pct}%)</span><b>{money(pool * s.pct / 100)}</b></div>)}
        </div>
      </div>
      <div className="card">
        <div className="bar"><select value={fb} onChange={(e) => setFb(e.target.value)}><option value="">{T('bro')}: {T('all')}</option>{brokers.map((b) => <option key={b.id} value={b.id}>{b.full_name}</option>)}</select></div>
        <div className="tw"><table>
          <thead><tr>{['deal', 'total', 'coAmt', 'bro', 'pct', 'amount', 'status', 'hist'].map((h) => <th key={h}>{T(h)}</th>)}<th>{T('actions')}</th></tr></thead>
          <tbody>{vis.map(({ c, s, i }) => (
            <tr key={c.id + '-' + i}>
              <td>{dl(c.deal_id)}</td><td>{money(c.total)}</td><td>{money(c.total * c.company_pct / 100)} ({c.company_pct}%)</td><td>{bname(s.b)}</td><td>{s.pct}%</td><td>{money(amt(c, s))}</td>
              <td><span className={'tag ' + (s.status === 'paid' ? 'avail' : 'warm')}>{T(s.status)}</span></td>
              <td style={{ fontSize: 12, color: 'var(--mu)' }}>{s.log.map((l) => T(l.s) + ' ' + l.d.slice(5)).join(' › ')}</td>
              <td>{can.pay && <button className="btn o s" onClick={() => toggle(c, i)}>{s.status === 'due' ? T('paid') : T('due')}</button>}{' '}
                {can.pay && i === 0 && !c.splits.some((x) => x.status === 'paid') && <button className="btn o s" onClick={() => setEd({ c, sp: c.splits.map((x) => ({ b: x.b, pct: x.pct })) })}>{T('edit')}</button>}</td>
            </tr>))}</tbody>
        </table></div>
        <div style={{ marginTop: 10, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          {brokers.map((b) => { const l = lines.filter((x) => x.s.b === b.id), a = (st: string) => l.filter((x) => x.s.status === st).reduce((s, x) => s + amt(x.c, x.s), 0);
            return <span key={b.id}><b>{b.full_name}</b>: {T('due')} {money(a('due'))} · {T('paid')} {money(a('paid'))}</span>; })}
        </div>
      </div>
      {ed && <SpModal ed={ed} onClose={() => setEd(null)} onSave={saveSp} />}
    </div>
  );
}

function SpModal({ ed, onClose, onSave }: { ed: { c: Commission; sp: SP[] }; onClose: () => void; onSave: (c: Commission, sp: SP[]) => void }) {
  const { T } = useUi(); const { brokers } = useData();
  const [sp, setSp] = useState(ed.sp); const ok = sp.reduce((a, s) => a + (+s.pct || 0), 0) === 100;
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{T('edit')} — D-{ed.c.deal_id.slice(0, 4)}</h3>
      <Splits sp={sp} setSp={setSp} brokers={brokers} />
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}><button className="btn o" onClick={onClose}>{T('cancel')}</button><button className="btn g" disabled={!ok} onClick={() => onSave(ed.c, sp)}>{T('save')}</button></div>
    </Modal>
  );
}
