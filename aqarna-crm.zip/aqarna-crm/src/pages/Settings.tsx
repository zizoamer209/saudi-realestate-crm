import { useState } from 'react';
import { useAuth, useUi } from '../context';
import { supabase } from '../supabaseClient';
import { F, STG } from '../ui';
import { D } from '../i18n';
import type { Company } from '../types';

const PRE: [string, string][] = [['#0b1f3a', '#c9a24b'], ['#0b1f3a', '#0f9d76'], ['#123a5e', '#d4af37']];

export default function Settings() {
  const { T, lang, setLang, mode, setMode, notify } = useUi(); const { can, company, setCompany } = useAuth();
  const [d, setD] = useState<Company>(company!); const [busy, setBusy] = useState(false);
  const dis = !can.adm;
  const s = (k: keyof Company) => (e: React.ChangeEvent<HTMLInputElement>) => setD({ ...d, [k]: e.target.value });
  const sn = (k: string, i: 0 | 1, v: string) => { const cur = d.stage_names?.[k] || D['st_' + k]; const n: [string, string] = [cur[0], cur[1]]; n[i] = v; setD({ ...d, stage_names: { ...(d.stage_names || {}), [k]: n } }); };
  const up = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return; if (f.size > 400000) { notify(T('big')); return; }
    const r = new FileReader(); r.onload = () => setD({ ...d, logo: String(r.result) }); r.readAsDataURL(f);
  };
  const brand = (p: string, a: string) => { setD({ ...d, brand_primary: p, brand_accent: a }); setCompany({ ...company!, brand_primary: p, brand_accent: a }); }; // instant preview
  const save = async () => {
    setBusy(true);
    const { id, ...patch } = d; void id;
    const { data, error } = await supabase.from('companies').update(patch).eq('id', company!.id).select().single();
    setBusy(false);
    if (error) notify(error.message); else { setCompany(data as Company); notify(T('saved2')); }
  };
  return (
    <div style={{ display: 'grid', gap: 14, maxWidth: 820 }}>
      <div className="card"><b>{T('cinfo')}</b>
        <div className="fg" style={{ marginTop: 10 }}>
          <F l={T('cnameAr')}><input disabled={dis} value={d.name_ar} onChange={s('name_ar')} /></F>
          <F l={T('cnameEn')}><input disabled={dis} dir="ltr" value={d.name_en} onChange={s('name_en')} /></F>
          <F l={T('phone')}><input disabled={dis} dir="ltr" value={d.phone ?? ''} onChange={s('phone')} /></F>
          <F l={T('email')}><input disabled={dis} dir="ltr" value={d.email ?? ''} onChange={s('email')} /></F>
          <F l={T('address')}><input disabled={dis} value={d.address ?? ''} onChange={s('address')} /></F>
          <F l={T('cur')}><select disabled><option>SAR — ريال سعودي</option></select></F>
          <F l={T('logo')} full><div className="bar" style={{ alignItems: 'center' }}>
            {d.logo && <img src={d.logo} alt="" style={{ height: 40, borderRadius: 6 }} />}
            <input type="file" accept="image/*" disabled={dis} onChange={up} />
            {d.logo && !dis && <button className="btn o s" onClick={() => setD({ ...d, logo: '' })}>✕</button>}</div></F>
        </div>
      </div>
      <div className="card"><b>{T('stages')}</b>
        <div className="fg" style={{ marginTop: 10 }}>{STG.map((k) => { const v = d.stage_names?.[k] || D['st_' + k]; return (
          <div key={k} className="full" style={{ display: 'flex', gap: 8 }}>
            <input disabled={dis} value={v[0]} onChange={(e) => sn(k, 0, e.target.value)} /><input disabled={dis} dir="ltr" value={v[1]} onChange={(e) => sn(k, 1, e.target.value)} /></div>); })}</div>
      </div>
      <div className="card"><b>{T('cdef')}</b>
        <div className="fg" style={{ marginTop: 10 }}>
          <F l={T('rate')}><input type="number" step="0.1" disabled={dis} value={d.commission_rate} onChange={(e) => setD({ ...d, commission_rate: +e.target.value })} /></F>
          <F l={T('co')}><input type="number" disabled={dis} value={d.company_share} onChange={(e) => setD({ ...d, company_share: Math.min(100, Math.max(0, +e.target.value)) })} /></F>
          <F l={T('br')}><input disabled value={100 - d.company_share} /></F>
        </div>
      </div>
      <div className="card"><b>{T('theme')}</b>
        <div className="fg" style={{ marginTop: 10 }}>
          <F l={T('lang')}><select value={lang} onChange={(e) => setLang(e.target.value as 'ar' | 'en')}><option value="ar">العربية (RTL)</option><option value="en">English (LTR)</option></select></F>
          <F l={T('mode')}><select value={mode} onChange={(e) => setMode(e.target.value)}><option value="auto">Auto</option><option value="light">Light</option><option value="dark">Dark</option></select></F>
          <F l={T('primary')}><input type="color" disabled={dis} value={d.brand_primary} onChange={(e) => brand(e.target.value, d.brand_accent)} /></F>
          <F l={T('accent')}><input type="color" disabled={dis} value={d.brand_accent} onChange={(e) => brand(d.brand_primary, e.target.value)} /></F>
          <F l="" full><div className="bar">{PRE.map((p, i) => <button key={i} disabled={dis} className="btn o" onClick={() => brand(p[0], p[1])}>
            <span style={{ display: 'inline-block', width: 18, height: 18, borderRadius: 9, background: p[0], border: '3px solid ' + p[1], verticalAlign: 'middle' }} /> {i + 1}</button>)}</div></F>
        </div>
      </div>
      {!dis && <div className="bar"><button className="btn g" disabled={busy} onClick={save}>{T('save')}</button></div>}
    </div>
  );
}
