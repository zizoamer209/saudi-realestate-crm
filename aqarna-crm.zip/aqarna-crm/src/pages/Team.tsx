import { useData, useUi } from '../context';
import { amt, isOpen } from '../ui';

export default function Team() {
  const { T, money } = useUi(); const { brokers, leads, deals, comm } = useData();
  const rows = brokers.map((b) => {
    const my = deals.rows.filter((d) => d.broker_id === b.id), w = my.filter((d) => d.stage === 'won');
    let due = 0, paid = 0;
    comm.rows.forEach((c) => c.splits.forEach((s) => { if (s.b === b.id) { if (s.status === 'paid') paid += amt(c, s); else due += amt(c, s); } }));
    return { b, cl: leads.rows.filter((l) => l.broker_id === b.id).length, o: my.filter((d) => isOpen(d.stage)).length, w: w.length, v: w.reduce((s, d) => s + d.value, 0), cm: due + paid, conv: my.length ? Math.round(w.length / my.length * 100) : 0 };
  }).sort((a, b) => b.v - a.v);
  const mx = Math.max(...rows.map((r) => r.v), 1);
  return (
    <>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(250px,1fr))' }}>
        {rows.map((r) => (
          <div className="card" key={r.b.id}><b style={{ fontSize: 17 }}>👤 {r.b.full_name}</b>
            {([['clients', r.cl], ['openD', r.o], ['wonD', r.w], ['salesv', money(r.v)], ['comms', money(r.cm)], ['conv', r.conv + '%']] as [string, string | number][]).map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid var(--bd)' }}><span style={{ color: 'var(--mu)' }}>{T(k)}</span><b>{v}</b></div>))}
          </div>))}
      </div>
      <div className="card"><div className="tw"><table>
        <thead><tr>{['rank', 'name', 'clients', 'openD', 'wonD', 'salesv', 'comms', 'conv'].map((h) => <th key={h}>{T(h)}</th>)}<th></th></tr></thead>
        <tbody>{rows.map((r, i) => (
          <tr key={r.b.id}><td>{i === 0 ? '🥇' : i + 1}</td><td>{r.b.full_name}</td><td>{r.cl}</td><td>{r.o}</td><td>{r.w}</td><td>{money(r.v)}</td><td>{money(r.cm)}</td><td>{r.conv}%</td>
            <td style={{ width: 160 }}><div style={{ height: 10, borderRadius: 5, background: 'var(--a)', width: Math.max(r.v / mx * 100, 3) + '%' }} /></td></tr>))}</tbody>
      </table></div></div>
    </>
  );
}
