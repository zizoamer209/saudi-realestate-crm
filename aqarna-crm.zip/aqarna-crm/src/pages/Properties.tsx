import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, Modal, TY } from '../ui';
import type { Property } from '../types';

export default function Properties() {
  const { T, money } = useUi(); const { can } = useAuth(); const { properties, leads } = useData();
  const [q, setQ] = useState(''), [st, setSt] = useState(''), [cd, setCd] = useState('');
  const [ed, setEd] = useState<Partial<Property> | null>(null);
  const rows = properties.rows.filter((p) => (!st || p.status === st) && (p.no + p.project + p.city + p.district).includes(q));
  const ln = (id: string | null) => leads.rows.find((l) => l.id === id)?.name || '—';
  return (
    <>
      <div className="card">
        <div className="bar">
          <input placeholder={T('search')} value={q} onChange={(e) => setQ(e.target.value)} />
          <select value={st} onChange={(e) => setSt(e.target.value)}><option value="">{T('status')}: {T('all')}</option>{['avail', 'res', 'sold'].map((x) => <option key={x} value={x}>{T(x)}</option>)}</select>
          {can.edit && <button className="btn g" onClick={() => setEd({ no: 'P-' + (1001 + properties.rows.length), project: '', type: 'apt', city: '', district: '', price: 0, area: 0, status: 'avail', lead_id: null, deal_id: null })}>+ {T('add')}</button>}
        </div>
        <div className="tw"><table>
          <thead><tr>{['no', 'project', 'type', 'city', 'price', 'area', 'status', 'lead', 'deal', 'actions'].map((h) => <th key={h}>{T(h)}</th>)}</tr></thead>
          <tbody>{rows.map((p) => (
            <tr key={p.id}>
              <td>{p.no}</td><td>{p.project}</td><td>{T(p.type)}</td><td>{p.city} – {p.district}</td><td>{money(p.price)}</td><td>{p.area}</td>
              <td><span className={'tag ' + p.status}>{T(p.status)}</span></td><td>{ln(p.lead_id)}</td><td>{p.deal_id ? 'D-' + p.deal_id.slice(0, 4) : '—'}</td>
              <td>
                {can.edit && <button className="btn o s" onClick={() => setEd({ ...p })}>{T('edit')}</button>}{' '}
                {can.del && (cd === p.id
                  ? <button className="btn r s" onClick={async () => { await properties.remove(p.id); setCd(''); }}>{T('sure')}</button>
                  : <button className="btn o s" onClick={() => setCd(p.id)}>{T('del')}</button>)}
              </td>
            </tr>))}</tbody>
        </table></div>
      </div>
      {ed && <PropForm d={ed} onClose={() => setEd(null)} />}
    </>
  );
}

function PropForm({ d, onClose }: { d: Partial<Property>; onClose: () => void }) {
  const { T } = useUi(); const { properties, leads, deals } = useData();
  const [f, setF] = useState(d), [tried, setTried] = useState(false);
  const s = (k: keyof Property) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const n = (k: keyof Property) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: +e.target.value });
  const bad = !(f.project || '').trim() || !(f.city || '').trim() || !((f.price || 0) > 0);
  const save = async () => {
    setTried(true); if (bad) return;
    const row = { no: f.no, project: f.project, type: f.type, city: f.city, district: f.district, price: f.price, area: f.area, status: f.status, lead_id: f.lead_id || null, deal_id: f.deal_id || null };
    const ok = f.id ? await properties.update(f.id, row) : await properties.insert(row);
    if (ok) onClose();
  };
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{f.id ? T('edit') : T('add')}</h3>
      <div className="fg">
        <F l={T('no')}><input value={f.no} onChange={s('no')} /></F>
        <F l={T('project')}><input value={f.project} onChange={s('project')} /></F>
        <F l={T('type')}><select value={f.type} onChange={s('type')}>{TY.map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('status')}><select value={f.status} onChange={s('status')}>{['avail', 'res', 'sold'].map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('city')}><input value={f.city} onChange={s('city')} /></F>
        <F l={T('district')}><input value={f.district} onChange={s('district')} /></F>
        <F l={T('price') + ' (SAR)'}><input type="number" value={f.price} onChange={n('price')} /></F>
        <F l={T('area')}><input type="number" value={f.area} onChange={n('area')} /></F>
        <F l={T('lead')}><select value={f.lead_id ?? ''} onChange={(e) => setF({ ...f, lead_id: e.target.value || null })}><option value="">{T('none')}</option>{leads.rows.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></F>
        <F l={T('deal')}><select value={f.deal_id ?? ''} onChange={(e) => setF({ ...f, deal_id: e.target.value || null })}><option value="">{T('none')}</option>
          {deals.rows.filter((x) => !f.lead_id || x.lead_id === f.lead_id).map((x) => <option key={x.id} value={x.id}>D-{x.id.slice(0, 4)} · {(x.value / 1e6).toFixed(2)}M · {x.stage}</option>)}</select></F>
      </div>
      {tried && bad && <div className="err">{T('bad')}</div>}
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}><button className="btn o" onClick={onClose}>{T('cancel')}</button><button className="btn g" onClick={save}>{T('save')}</button></div>
    </Modal>
  );
}
