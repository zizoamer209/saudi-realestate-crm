import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, LV, Modal, SRC, TY, norm } from '../ui';
import type { Lead } from '../types';

export default function Leads() {
  const { T, money } = useUi(); const { can, profile } = useAuth(); const { leads, brokers, bname } = useData();
  const [q, setQ] = useState(''), [lv, setLv] = useState(''), [cd, setCd] = useState('');
  const [ed, setEd] = useState<Partial<Lead> | null>(null);
  const rows = leads.rows.filter((l) => (!lv || l.level === lv) && (l.name + l.phone + l.city + l.district).includes(q));
  const blank = (): Partial<Lead> => ({
    name: '', phone: '', source: 'website', budget: 0, type: 'apt', city: '', district: '', level: 'warm', notes: [],
    broker_id: profile!.role === 'broker' ? profile!.id : brokers[0]?.id ?? null,
  });
  return (
    <>
      <div className="card">
        <div className="bar">
          <input placeholder={T('search')} value={q} onChange={(e) => setQ(e.target.value)} />
          <select value={lv} onChange={(e) => setLv(e.target.value)}><option value="">{T('level')}: {T('all')}</option>{LV.map((x) => <option key={x} value={x}>{T(x)}</option>)}</select>
          {can.edit && <button className="btn g" onClick={() => setEd(blank())}>+ {T('add')}</button>}
        </div>
        <div className="tw"><table>
          <thead><tr>{['name', 'phone', 'source', 'budget', 'type', 'city', 'bro', 'level', 'actions'].map((h) => <th key={h}>{T(h)}</th>)}</tr></thead>
          <tbody>{rows.map((l) => (
            <tr key={l.id}>
              <td>{l.name}</td><td dir="ltr">{l.phone}</td><td>{T(l.source)}</td><td>{money(l.budget)}</td><td>{T(l.type)}</td>
              <td>{l.city} – {l.district}</td><td>{bname(l.broker_id)}</td><td><span className={'tag ' + l.level}>{T(l.level)}</span></td>
              <td>
                {can.edit && <button className="btn o s" onClick={() => setEd({ ...l })}>{T('edit')}</button>}{' '}
                {can.del && (cd === l.id
                  ? <button className="btn r s" onClick={async () => { await leads.remove(l.id); setCd(''); }}>{T('sure')}</button>
                  : <button className="btn o s" onClick={() => setCd(l.id)}>{T('del')}</button>)}
              </td>
            </tr>))}</tbody>
        </table></div>
      </div>
      {ed && <LeadForm d={ed} onClose={() => setEd(null)} />}
    </>
  );
}

function LeadForm({ d, onClose }: { d: Partial<Lead>; onClose: () => void }) {
  const { T } = useUi(); const { can } = useAuth(); const { leads, brokers } = useData();
  const [f, setF] = useState(d), [nn, setNn] = useState(''), [tried, setTried] = useState(false), [busy, setBusy] = useState(false);
  const s = (k: keyof Lead) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const phone = f.phone || '';
  const dup = norm(phone).length > 0 && leads.rows.some((l) => l.id !== f.id && l.phone_norm === norm(phone));
  const bad = !(f.name || '').trim() || norm(phone).length < 9;
  const notes = f.notes || [];
  const save = async () => {
    setTried(true); if (bad || dup) return; setBusy(true);
    const row = { name: f.name!.trim(), phone: phone.trim(), phone_norm: norm(phone), source: f.source, budget: f.budget || 0, type: f.type, city: f.city, district: f.district, level: f.level, broker_id: f.broker_id || null, notes };
    const ok = f.id ? await leads.update(f.id, row) : await leads.insert(row);
    setBusy(false); if (ok) onClose();
  };
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{f.id ? T('edit') : T('add')}</h3>
      <div className="fg">
        <F l={T('name')}><input value={f.name} onChange={s('name')} /></F>
        <F l={T('phone')}><input dir="ltr" value={phone} onChange={s('phone')} style={dup ? { borderColor: '#c0262d' } : {}} />{dup && <div className="err">⚠ {T('dup')}</div>}</F>
        <F l={T('source')}><select value={f.source} onChange={s('source')}>{SRC.map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('budget') + ' (SAR)'}><input type="number" value={f.budget} onChange={(e) => setF({ ...f, budget: +e.target.value })} /></F>
        <F l={T('type')}><select value={f.type} onChange={s('type')}>{TY.map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('level')}><select value={f.level} onChange={s('level')}>{LV.map((x) => <option key={x} value={x}>{T(x)}</option>)}</select></F>
        <F l={T('city')}><input value={f.city} onChange={s('city')} /></F>
        <F l={T('district')}><input value={f.district} onChange={s('district')} /></F>
        <F l={T('bro')}><select disabled={!can.del} value={f.broker_id ?? ''} onChange={(e) => setF({ ...f, broker_id: e.target.value || null })}>
          {brokers.map((b) => <option key={b.id} value={b.id}>{b.full_name}</option>)}</select></F>
        <F l={T('notes')} full>
          <div className="bar"><input value={nn} onChange={(e) => setNn(e.target.value)} />
            <button className="btn o s" onClick={() => { if (nn.trim()) { setF({ ...f, notes: [{ d: new Date().toISOString().slice(0, 10), t: nn.trim() }, ...notes] }); setNn(''); } }}>{T('addnote')}</button></div>
          {notes.map((n, i) => <div key={i} style={{ fontSize: 13, padding: '4px 0', borderBottom: '1px solid var(--bd)' }}><span style={{ color: 'var(--mu)' }}>{n.d}</span> — {n.t}</div>)}
        </F>
      </div>
      {tried && bad && !dup && <div className="err">{T('bad')}</div>}
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}>
        <button className="btn o" onClick={onClose}>{T('cancel')}</button>
        <button className="btn g" disabled={dup || busy} style={dup ? { opacity: 0.5 } : {}} onClick={save}>{T('save')}</button>
      </div>
    </Modal>
  );
}
