import { useState } from 'react';
import { useData, useUi } from '../context';
import { SRC, dmonth, today } from '../ui';

export default function Reports() {
  const { T, money } = useUi(); const { leads, deals, brokers } = useData();
  const [tab, setTab] = useState('br'), [mo, setMo] = useState('');
  const months = [...new Set(deals.rows.map(dmonth))].filter(Boolean).sort();
  const fd = deals.rows.filter((d) => !mo || dmonth(d) === mo);
  const won = (s: string) => s === 'won';
  const sv = (a: { value: number }[]) => a.reduce((s, d) => s + d.value, 0);
  const pc = (a: number, b: number) => (b ? Math.round(a / b * 100) + '%' : '0%');
  let head: string[], rows: (string | number)[][];
  if (tab === 'br') {
    head = [T('bro'), T('wonD'), T('salesv'), T('conv')];
    rows = brokers.map((b) => { const my = fd.filter((d) => d.broker_id === b.id), w = my.filter((d) => won(d.stage)); return [b.full_name, w.length, sv(w), pc(w.length, my.length)]; });
  } else if (tab === 'src') {
    head = [T('source'), T('clients'), T('budget')];
    rows = SRC.map((s) => { const l = leads.rows.filter((x) => x.source === s); return [T(s), l.length, l.reduce((a, x) => a + (+x.budget || 0), 0)]; });
  } else if (tab === 'mo') {
    head = [T('date'), T('wonD'), T('salesv'), 'Δ%'];
    rows = months.map((m, i) => {
      const w = deals.rows.filter((d) => dmonth(d) === m && won(d.stage)), v = sv(w), p = i ? sv(deals.rows.filter((d) => dmonth(d) === months[i - 1] && won(d.stage))) : 0;
      return [m, w.length, v, p ? Math.round((v - p) / p * 100) + '%' : '—'];
    });
  } else {
    head = [T('bro'), T('deal'), T('wonD'), T('st_lost'), T('conv')];
    rows = brokers.map((b) => { const my = fd.filter((d) => d.broker_id === b.id), w = my.filter((d) => won(d.stage)).length; return [b.full_name, my.length, w, my.filter((d) => d.stage === 'lost').length, pc(w, my.length)]; });
    rows.push(['Σ', fd.length, fd.filter((d) => won(d.stage)).length, fd.filter((d) => d.stage === 'lost').length, pc(fd.filter((d) => won(d.stage)).length, fd.length)]);
  }
  const bi = tab === 'src' ? 1 : 2;
  const mx = Math.max(...rows.filter((_, i) => tab !== 'cv' || i < rows.length - 1).map((r) => Number(r[bi]) || 0), 1);
  // Real CSV download — UTF-8 with BOM so Excel shows Arabic correctly.
  const exp = () => {
    const q = (v: unknown) => '"' + String(v).replace(/"/g, '""') + '"';
    const csv = '\ufeff' + [head, ...rows].map((r) => r.map(q).join(',')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `report-${tab}-${today()}.csv`; a.click(); URL.revokeObjectURL(a.href);
  };
  return (
    <div className="card">
      <div className="bar">
        {['br', 'src', 'mo', 'cv'].map((k) => <button key={k} className={'btn ' + (tab === k ? 'g' : 'o')} onClick={() => setTab(k)}>{T('rp_' + k)}</button>)}
        {(tab === 'br' || tab === 'cv') && <select value={mo} onChange={(e) => setMo(e.target.value)}><option value="">{T('date')}: {T('all')}</option>{months.map((m) => <option key={m} value={m}>{m}</option>)}</select>}
        <button className="btn o" onClick={exp}>⬇ {T('csv')}</button>
      </div>
      <div className="tw"><table>
        <thead><tr>{head.map((h) => <th key={h}>{h}</th>)}<th></th></tr></thead>
        <tbody>{rows.map((r, i) => (
          <tr key={i}>{r.map((v, j) => <td key={j}>{j === 2 && tab !== 'cv' && typeof v === 'number' ? money(v) : v}</td>)}
            <td style={{ width: 170 }}><div style={{ height: 10, borderRadius: 5, background: 'var(--a)', width: Math.min(100, Math.max((Number(r[bi]) || 0) / mx * 100, 2)) + '%' }} /></td></tr>))}</tbody>
      </table></div>
    </div>
  );
}
