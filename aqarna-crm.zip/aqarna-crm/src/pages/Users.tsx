import { useState } from 'react';
import { useAuth, useData, useUi } from '../context';
import { F, Modal } from '../ui';
import type { Profile, Role } from '../types';

const R: Role[] = ['admin', 'sales', 'broker', 'acct'];
const P: [string, Role[]][] = [['leads', ['admin', 'sales', 'broker']], ['del', ['admin', 'sales']], ['team', ['admin', 'sales']], ['finance', ['admin', 'sales', 'acct']], ['mark', ['admin', 'acct']], ['settings', ['admin']], ['contracts', ['admin']]];

export default function Users() {
  const { T, notify } = useUi(); const { can } = useAuth(); const { team, invites } = useData();
  const [ed, setEd] = useState<{ email: string; full_name: string; role: Role } | null>(null);
  // never leave the company without an active admin
  const upd = (u: Profile, p: Partial<Profile>) => {
    const n = { ...u, ...p };
    if (u.role === 'admin' && u.active && (!n.active || n.role !== 'admin') && !team.rows.some((x) => x.id !== u.id && x.role === 'admin' && x.active)) { notify(T('lastadm')); return; }
    team.update(u.id, p);
  };
  return (
    <div>
      <div className="card">
        {can.adm && <div className="bar"><button className="btn g" onClick={() => setEd({ email: '', full_name: '', role: 'broker' })}>+ {T('addemp')}</button></div>}
        <div className="tw"><table>
          <thead><tr>{['name', 'email', 'role', 'status'].map((h) => <th key={h}>{T(h)}</th>)}<th>{T('actions')}</th></tr></thead>
          <tbody>{team.rows.map((u) => (
            <tr key={u.id} style={{ opacity: u.active ? 1 : 0.55 }}>
              <td>{u.full_name}</td><td dir="ltr">{u.email}</td>
              <td><select disabled={!can.adm} value={u.role} onChange={(e) => upd(u, { role: e.target.value as Role })} style={{ width: 'auto' }}>{R.map((r) => <option key={r} value={r}>{T(r)}</option>)}</select></td>
              <td><span className={'tag ' + (u.active ? 'avail' : 'cold')}>{T(u.active ? 'on' : 'off')}</span></td>
              <td>{can.adm && <button className="btn o s" onClick={() => upd(u, { active: !u.active })}>{u.active ? T('deact') : T('act')}</button>}</td>
            </tr>))}</tbody>
        </table></div>
      </div>
      {can.adm && invites.rows.length > 0 && (
        <div className="card" style={{ marginTop: 14 }}><b>{T('invited')}</b>
          {invites.rows.map((i) => <div key={i.id} style={{ display: 'flex', gap: 10, padding: '6px 0', alignItems: 'center' }}><span dir="ltr" style={{ flex: 1 }}>{i.email} · {i.full_name}</span><span className="tag">{T(i.role)}</span><button className="btn o s" onClick={() => invites.remove(i.id)}>✕</button></div>)}
        </div>)}
      <div className="card" style={{ marginTop: 14 }}><b>{T('perm')}</b><div className="tw"><table>
        <thead><tr><th></th>{R.map((r) => <th key={r}>{T(r)}</th>)}</tr></thead>
        <tbody>{P.map(([k, rs]) => <tr key={k}><td>{T(k)}</td>{R.map((r) => <td key={r}>{rs.includes(r) ? '✓' : '—'}</td>)}</tr>)}</tbody>
      </table></div></div>
      {ed && <InviteForm d={ed} onClose={() => setEd(null)} />}
    </div>
  );
}

function InviteForm({ d, onClose }: { d: { email: string; full_name: string; role: Role }; onClose: () => void }) {
  const { T } = useUi(); const { team, invites } = useData();
  const [f, setF] = useState(d);
  const em = f.email.trim().toLowerCase();
  const dup = team.rows.some((u) => u.email.toLowerCase() === em) || invites.rows.some((i) => i.email.toLowerCase() === em);
  const bad = !f.full_name.trim() || !/^\S+@\S+\.\S+$/.test(em);
  return (
    <Modal onClose={onClose}>
      <h3 style={{ marginTop: 0 }}>{T('addemp')}</h3>
      <div className="fg">
        <F l={T('name')}><input value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></F>
        <F l={T('email')}><input dir="ltr" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />{dup && <div className="err">⚠ {T('dupmail')}</div>}</F>
        <F l={T('role')}><select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>{R.map((r) => <option key={r} value={r}>{T(r)}</option>)}</select></F>
      </div>
      <p style={{ fontSize: 13, color: 'var(--mu)' }}>{T('invNote')}</p>
      <div className="bar" style={{ marginTop: 14, justifyContent: 'flex-end' }}><button className="btn o" onClick={onClose}>{T('cancel')}</button>
        <button className="btn g" disabled={bad || dup} onClick={async () => { if (await invites.insert({ email: em, full_name: f.full_name.trim(), role: f.role })) onClose(); }}>{T('save')}</button></div>
    </Modal>
  );
}
