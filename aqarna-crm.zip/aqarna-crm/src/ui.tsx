import type { ReactNode } from 'react';
import { useUi } from './context';
import type { Commission, Deal, Profile, Split } from './types';

export const STG = ['new', 'contact', 'view', 'nego', 'offer', 'contract', 'won', 'lost'] as const;
export const LV = ['hot', 'warm', 'cold'], TY = ['apt', 'villa', 'land', 'comm'], SRC = ['website', 'ref', 'social', 'call'];
export const today = () => new Date().toISOString().slice(0, 10);
export const dayp = (n: number) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
export const norm = (p: string) => String(p).replace(/\D/g, '').replace(/^(966|00966)/, '').replace(/^0/, '');
export const isOpen = (s: string) => s !== 'won' && s !== 'lost';
export const dmonth = (d: Deal) => d.closed_month || (d.created_at || '').slice(0, 7);
export const amt = (c: Commission, s: Split) => Math.round(c.total * (100 - c.company_pct) / 100 * s.pct / 100);

export const Modal = ({ children, onClose }: { children: ReactNode; onClose: () => void }) => (
  <div className="ov" onClick={(e) => e.target === e.currentTarget && onClose()}><div className="md">{children}</div></div>
);
export const F = ({ l, children, full }: { l: string; children: ReactNode; full?: boolean }) => (
  <div className={full ? 'full' : ''}><label>{l}</label>{children}</div>
);

type SP = { b: string; pct: number };
export function Splits({ sp, setSp, brokers, dis }: { sp: SP[]; setSp: (s: SP[]) => void; brokers: Profile[]; dis?: boolean }) {
  const { T } = useUi();
  const sm = sp.reduce((a, s) => a + (+s.pct || 0), 0);
  const up = (i: number, p: Partial<SP>) => setSp(sp.map((x, j) => (j === i ? { ...x, ...p } : x)));
  return (
    <div>
      {sp.map((s, i) => (
        <div key={i} className="bar" style={{ marginBottom: 6 }}>
          <select disabled={dis} value={s.b} onChange={(e) => up(i, { b: e.target.value })}>
            {brokers.map((b) => <option key={b.id} value={b.id}>{b.full_name}</option>)}
          </select>
          <input type="number" disabled={dis} value={s.pct} onChange={(e) => up(i, { pct: +e.target.value })} />
          {!dis && sp.length > 1 && <button className="btn o s" onClick={() => setSp(sp.filter((_, j) => j !== i))}>✕</button>}
        </div>
      ))}
      {!dis && sp.length < brokers.length && (
        <button className="btn o s" onClick={() => setSp([...sp, { b: (brokers.find((b) => !sp.some((s) => s.b === b.id)) || brokers[0]).id, pct: 0 }])}>{T('addb')}</button>
      )}{' '}
      <span className={sm === 100 ? '' : 'err'}>{sm}%{sm !== 100 ? ' — ' + T('sum100') : ''}</span>
    </div>
  );
}
