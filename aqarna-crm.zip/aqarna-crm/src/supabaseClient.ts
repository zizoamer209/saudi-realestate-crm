import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const configured = Boolean(url && key);

// Placeholder values only keep the app from crashing when env vars are missing;
// <App/> shows a configuration error screen in that case.
export const supabase = createClient(url || 'http://localhost:54321', key || 'missing-anon-key');
