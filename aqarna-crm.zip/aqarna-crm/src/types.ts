export type Role = 'admin' | 'sales' | 'broker' | 'acct';
export type Stage = 'new' | 'contact' | 'view' | 'nego' | 'offer' | 'contract' | 'won' | 'lost';
export interface Note { d: string; t: string }
export interface Profile { id: string; company_id: string; full_name: string; email: string; role: Role; active: boolean }
export interface Company {
  id: string; name_ar: string; name_en: string; phone: string | null; email: string | null; address: string | null;
  logo: string | null; currency: string; stage_names: Record<string, [string, string]>;
  commission_rate: number; company_share: number; brand_primary: string; brand_accent: string;
}
export interface Lead {
  id: string; company_id: string; name: string; phone: string; phone_norm: string; source: string; budget: number;
  type: string; city: string; district: string; level: string; broker_id: string | null; notes: Note[]; created_at?: string;
}
export interface Property {
  id: string; company_id: string; no: string; project: string; type: string; city: string; district: string;
  price: number; area: number; status: 'avail' | 'res' | 'sold'; lead_id: string | null; deal_id: string | null;
}
export interface Deal {
  id: string; company_id: string; lead_id: string | null; property_id: string | null; value: number; stage: Stage;
  broker_id: string | null; follow_date: string; closed_month: string | null; created_at?: string;
}
export interface Split { b: string; pct: number; status: 'due' | 'paid'; log: { d: string; s: string }[] }
export interface Commission { id: string; company_id: string; deal_id: string; rate: number; company_pct: number; total: number; splits: Split[] }
export interface Activity {
  id: string; company_id: string; type: 'call' | 'visit' | 'meet'; title: string; lead_id: string | null;
  due_date: string; due_time: string; done: boolean; notes: Note[];
}
export interface Invitation { id: string; company_id: string; email: string; full_name: string; role: Role }
