import { useState } from 'react';
import { useAuth, useUi } from './context';
import { F } from './ui';

export default function Login() {
  const { T, ar, setLang, lang } = useUi();
  const { signIn, signUp, authErr } = useAuth();
  const [tab, setTab] = useState<'in' | 'up'>('in');
  const [f, setF] = useState({ email: '', password: '', name: '', company: '' });
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const s = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async () => {
    setBusy(true); setMsg('');
    if (tab === 'in') { const e = await signIn(f.email.trim(), f.password); if (e) setMsg(e); }
    else {
      const r = await signUp(f.email.trim(), f.password, f.name.trim(), f.company.trim());
      if (r.error) setMsg(r.error); else if (!r.session) setMsg(T('confirmMail'));
    }
    setBusy(false);
  };
  const bad = !f.email.includes('@') || f.password.length < 6 || (tab === 'up' && !f.name.trim());
  return (
    <div className="auth" dir={ar ? 'rtl' : 'ltr'}>
      <div className="card">
        <h1>🏛 Aqarna CRM</h1>
        <div className="tabs">
          <button className={'btn ' + (tab === 'in' ? 'g' : 'o')} onClick={() => setTab('in')}>{T('login')}</button>
          <button className={'btn ' + (tab === 'up' ? 'g' : 'o')} onClick={() => setTab('up')}>{T('register')}</button>
        </div>
        <div className="fg">
          {tab === 'up' && <F l={T('fullName')}><input value={f.name} onChange={s('name')} /></F>}
          {tab === 'up' && <F l={T('companyName')}><input value={f.company} onChange={s('company')} /></F>}
          <F l={T('email')}><input dir="ltr" type="email" value={f.email} onChange={s('email')} /></F>
          <F l={T('password')}><input dir="ltr" type="password" value={f.password} onChange={s('password')} onKeyDown={(e) => e.key === 'Enter' && !bad && submit()} /></F>
        </div>
        {(msg || authErr) && <div className="err" style={{ marginTop: 10 }}>{msg || T(authErr)}</div>}
        <div className="bar" style={{ marginTop: 14, marginBottom: 0 }}>
          <button className="btn g" disabled={bad || busy} onClick={submit} style={{ flex: 1 }}>{tab === 'in' ? T('login') : T('register')}</button>
          <button className="btn o" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{lang === 'ar' ? 'English' : 'العربية'}</button>
        </div>
      </div>
    </div>
  );
}
