import { useState } from 'react';
import { AuthProvider, DataProvider, UiProvider, useAuth, useData, useUi } from './context';
import { configured } from './supabaseClient';
import Login from './Login';
import Dashboard from './pages/Dashboard';
import Leads from './pages/Leads';
import Properties from './pages/Properties';
import Pipeline from './pages/Pipeline';
import Team from './pages/Team';
import Finance from './pages/Finance';
import Follow from './pages/Follow';
import Reports from './pages/Reports';
import Users from './pages/Users';
import Settings from './pages/Settings';

const PAGES: Record<string, () => JSX.Element> = {
  dashboard: Dashboard, leads: Leads, properties: Properties, deals: Pipeline, tasks: Follow,
  finance: Finance, contracts: Users, reports: Reports, team: Team, settings: Settings,
};

function Shell() {
  const { T, ar, lang, setLang, msg } = useUi();
  const { profile, company, can, allow, signOut } = useAuth();
  const { loading } = useData();
  const [sec, setSec] = useState('dashboard');
  const cur = allow.includes(sec) ? sec : 'dashboard';
  const Page = PAGES[cur];
  return (
    <div className="app">
      <nav className="side">
        <div className="logo">
          {company?.logo ? <img src={company.logo} alt="" style={{ height: 26, verticalAlign: 'middle', borderRadius: 4 }} /> : '🏛'} {ar ? company?.name_ar : company?.name_en || company?.name_ar}
        </div>
        {allow.map((s) => <button key={s} className={'nav' + (cur === s ? ' on' : '')} onClick={() => setSec(s)}>{T(s)}</button>)}
        <div className="who" style={{ marginTop: 'auto' }}>{profile?.full_name}<br />{T(profile!.role)}</div>
        <button className="nav" onClick={signOut}>⏻ {T('logout')}</button>
      </nav>
      <main className="main">
        {msg && <div className="card" style={{ borderColor: 'var(--a)', marginBottom: 10 }}>{msg}</div>}
        <div className="top">
          <h2>{T(cur)}</h2>
          <span>
            {!can.edit && <span className="tag warm">{T('ro')}</span>}{' '}
            <button className="btn o s" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>{ar ? 'English' : 'العربية'}</button>
          </span>
        </div>
        {loading ? <div className="card">{T('loading')}</div> : <Page />}
      </main>
    </div>
  );
}

function Gate() {
  const { session, profile, ready, signOut } = useAuth();
  const { T } = useUi();
  if (!ready) return <div className="auth"><div className="card">{T('loading')}</div></div>;
  if (!session) return <Login />;
  if (!profile) return (
    <div className="auth"><div className="card"><p>{T('noProfile')}</p><button className="btn o" onClick={signOut}>{T('logout')}</button></div></div>
  );
  return <DataProvider><Shell /></DataProvider>;
}

export default function App() {
  if (!configured) return <div style={{ padding: 30, fontFamily: 'sans-serif' }}>⚠ Supabase env vars are missing / متغيرات Supabase غير مضبوطة — see .env.example</div>;
  return <AuthProvider><UiProvider><Gate /></UiProvider></AuthProvider>;
}
