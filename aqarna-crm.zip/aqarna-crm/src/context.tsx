import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabaseClient';
import { D } from './i18n';
import { today } from './ui';
import type { Activity, Commission, Company, Deal, Invitation, Lead, Profile, Property, Role, Stage } from './types';

/* ───────── Auth ───────── */
export interface Can { edit: boolean; del: boolean; pay: boolean; adm: boolean }
const ALLOW: Record<Role, string[]> = {
  admin: ['dashboard', 'leads', 'properties', 'deals', 'tasks', 'finance', 'contracts', 'reports', 'team', 'settings'],
  sales: ['dashboard', 'leads', 'properties', 'deals', 'tasks', 'finance', 'reports', 'team', 'settings'],
  broker: ['dashboard', 'leads', 'properties', 'deals', 'tasks', 'settings'],
  acct: ['dashboard', 'properties', 'deals', 'finance', 'reports', 'settings'],
};
interface AuthCtx {
  session: Session | null; profile: Profile | null; company: Company | null; ready: boolean; authErr: string;
  can: Can; allow: string[];
  signIn: (email: string, password: string) => Promise<string | null>;
  signUp: (email: string, password: string, fullName: string, companyName: string) => Promise<{ error: string | null; session: boolean }>;
  signOut: () => Promise<void>;
  setCompany: (c: Company) => void;
}
const AuthC = createContext<AuthCtx>(null!);
export const useAuth = () => useContext(AuthC);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [ready, setReady] = useState(false);
  const [authErr, setAuthErr] = useState('');

  // Fetch role + company_id from `profiles`, then the company row.
  const loadProfile = useCallback(async (uid: string) => {
    const { data: p } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (!p) { setProfile(null); setCompany(null); return; }
    if (!p.active) { setAuthErr('inactive'); await supabase.auth.signOut(); return; }
    const { data: c } = await supabase.from('companies').select('*').eq('id', p.company_id).single();
    setProfile(p as Profile); setCompany(c as Company); setAuthErr('');
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session) await loadProfile(data.session.user.id);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (s) setTimeout(() => loadProfile(s.user.id), 0); // never await supabase calls inside this callback
      else { setProfile(null); setCompany(null); }
    });
    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  const role = profile?.role ?? 'broker';
  const can: Can = { edit: role !== 'acct', del: role === 'admin' || role === 'sales', pay: role === 'admin' || role === 'acct', adm: role === 'admin' };
  const value: AuthCtx = {
    session, profile, company, ready, authErr, can, allow: ALLOW[role], setCompany,
    signIn: async (email, password) => { setAuthErr(''); const { error } = await supabase.auth.signInWithPassword({ email, password }); return error ? error.message : null; },
    signUp: async (email, password, fullName, companyName) => {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName, company_name: companyName } } });
      return { error: error ? error.message : null, session: Boolean(data?.session) };
    },
    signOut: async () => { await supabase.auth.signOut(); },
  };
  return <AuthC.Provider value={value}>{children}</AuthC.Provider>;
}

/* ───────── UI (language, theme, toast, money) ───────── */
type Lang = 'ar' | 'en';
interface Ui {
  lang: Lang; setLang: (l: Lang) => void; mode: string; setMode: (m: string) => void; ar: boolean;
  T: (k: string) => string; money: (n: number) => string; notify: (m: string) => void; msg: string;
}
const UiC = createContext<Ui>(null!);
export const useUi = () => useContext(UiC);

export function UiProvider({ children }: { children: ReactNode }) {
  const { company } = useAuth();
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('lang') as Lang) || 'ar');
  const [mode, setMode] = useState(() => localStorage.getItem('mode') || 'auto');
  const [msg, setMsg] = useState('');
  const ar = lang === 'ar';
  useEffect(() => { localStorage.setItem('lang', lang); const r = document.documentElement; r.lang = lang; r.dir = ar ? 'rtl' : 'ltr'; }, [lang, ar]);
  useEffect(() => { localStorage.setItem('mode', mode); const r = document.documentElement; if (mode === 'auto') r.removeAttribute('data-theme'); else r.setAttribute('data-theme', mode); }, [mode]);
  useEffect(() => { const r = document.documentElement; r.style.setProperty('--p', company?.brand_primary || '#0b1f3a'); r.style.setProperty('--a', company?.brand_accent || '#c9a24b'); }, [company]);
  useEffect(() => { if (msg) { const t = setTimeout(() => setMsg(''), 4500); return () => clearTimeout(t); } }, [msg]);
  const T = (k: string) => {
    if (k.startsWith('st_') && company?.stage_names?.[k.slice(3)]) return company.stage_names[k.slice(3)][ar ? 0 : 1];
    const v = D[k]; return v ? v[ar ? 0 : 1] : k;
  };
  const money = (n: number) => new Intl.NumberFormat(ar ? 'ar-SA' : 'en-US', { style: 'currency', currency: company?.currency || 'SAR', maximumFractionDigits: 0 }).format(n || 0);
  return <UiC.Provider value={{ lang, setLang, mode, setMode, ar, T, money, notify: setMsg, msg }}>{children}</UiC.Provider>;
}

/* ───────── Data (Supabase CRUD) ───────── */
export interface Tbl<R> {
  rows: R[]; loading: boolean;
  insert: (r: Partial<R>) => Promise<R | null>;
  update: (id: string, p: Partial<R>) => Promise<R | null>;
  remove: (id: string) => Promise<boolean>;
}
function useTable<R extends { id: string }>(table: string, cid: string, err: (e: { message: string; code?: string }) => void): Tbl<R> {
  const [rows, setRows] = useState<R[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let live = true;
    supabase.from(table).select('*').order('created_at', { ascending: true }).then(({ data, error }) => {
      if (!live) return; if (error) err(error); else setRows(data as R[]); setLoading(false);
    });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);
  return {
    rows, loading,
    insert: async (row) => {
      const { data, error } = await supabase.from(table).insert({ ...row, company_id: cid }).select().single();
      if (error) { err(error); return null; }
      setRows((r) => [...r, data as R]); return data as R;
    },
    update: async (id, patch) => {
      const { data, error } = await supabase.from(table).update(patch as never).eq('id', id).select().single();
      if (error) { err(error); return null; }
      setRows((r) => r.map((x) => (x.id === id ? (data as R) : x))); return data as R;
    },
    remove: async (id) => {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) { err(error); return false; }
      setRows((r) => r.filter((x) => x.id !== id)); return true;
    },
  };
}

interface DataCtx {
  leads: Tbl<Lead>; properties: Tbl<Property>; deals: Tbl<Deal>; comm: Tbl<Commission>; acts: Tbl<Activity>;
  team: Tbl<Profile>; invites: Tbl<Invitation>; brokers: Profile[]; bname: (id: string | null) => string;
  setStage: (id: string, st: Stage) => Promise<void>; loading: boolean;
}
const DataC = createContext<DataCtx>(null!);
export const useData = () => useContext(DataC);

export function DataProvider({ children }: { children: ReactNode }) {
  const { profile, company } = useAuth();
  const { T, notify } = useUi();
  const cid = profile!.company_id;
  const err = (e: { message: string; code?: string }) => notify(e.code === '23505' ? T('dup') : e.message);
  const leads = useTable<Lead>('leads', cid, err);
  const properties = useTable<Property>('properties', cid, err);
  const deals = useTable<Deal>('deals', cid, err);
  const comm = useTable<Commission>('commissions', cid, err);
  const acts = useTable<Activity>('activities', cid, err);
  const team = useTable<Profile>('profiles', cid, err);
  const invites = useTable<Invitation>('invitations', cid, err);
  const brokers = team.rows.filter((p) => p.role === 'broker' && p.active);
  const bname = (id: string | null) => team.rows.find((p) => p.id === id)?.full_name || '—';

  // Move a deal. Closing it creates the commission and marks the property as sold; re-opening reverses that.
  const setStage = async (id: string, st: Stage) => {
    const d = deals.rows.find((x) => x.id === id); if (!d || d.stage === st || !company) return;
    const cm = comm.rows.find((c) => c.deal_id === id);
    if (d.stage === 'won' && cm?.splits.some((s) => s.status === 'paid')) { notify(T('locked')); return; }
    const t = today();
    const upd = await deals.update(id, { stage: st, follow_date: t, closed_month: st === 'won' ? t.slice(0, 7) : null });
    if (!upd) return;
    if (st === 'won') {
      if (!cm) await comm.insert({
        deal_id: id, rate: company.commission_rate, company_pct: company.company_share,
        total: Math.round(d.value * company.commission_rate / 100),
        splits: [{ b: d.broker_id || profile!.id, pct: 100, status: 'due', log: [{ d: t, s: 'due' }] }],
      });
      if (d.property_id) await properties.update(d.property_id, { status: 'sold', lead_id: d.lead_id, deal_id: id });
      notify(T('gen'));
    } else if (d.stage === 'won') {
      if (cm) await comm.remove(cm.id);
      if (d.property_id) await properties.update(d.property_id, { status: 'res' });
    }
  };
  const loading = [leads, properties, deals, comm, acts, team].some((t) => t.loading);
  return <DataC.Provider value={{ leads, properties, deals, comm, acts, team, invites, brokers, bname, setStage, loading }}>{children}</DataC.Provider>;
}
