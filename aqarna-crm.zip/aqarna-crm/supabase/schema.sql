-- Aqarna CRM — run once in Supabase Dashboard > SQL Editor
create extension if not exists pgcrypto;

create table companies (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null, name_en text not null default '',
  phone text, email text, address text, logo text,
  currency text not null default 'SAR',
  stage_names jsonb not null default '{}',
  commission_rate numeric not null default 2.5,
  company_share numeric not null default 40,
  brand_primary text not null default '#0b1f3a',
  brand_accent text not null default '#c9a24b',
  created_at timestamptz not null default now()
);
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null references companies(id) on delete cascade,
  full_name text not null default '', email text not null default '',
  role text not null default 'broker' check (role in ('admin','sales','broker','acct')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table invitations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  email text not null, full_name text not null default '',
  role text not null default 'broker' check (role in ('admin','sales','broker','acct')),
  created_at timestamptz not null default now()
);
create unique index on invitations (company_id, lower(email));
create table leads (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  name text not null, phone text not null, phone_norm text not null,
  source text not null default 'website', budget numeric not null default 0,
  type text not null default 'apt', city text not null default '', district text not null default '',
  level text not null default 'warm',
  broker_id uuid references profiles(id) on delete set null,
  notes jsonb not null default '[]',
  created_at timestamptz not null default now()
);
create unique index on leads (company_id, phone_norm);   -- duplicate phone protection
create table properties (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  no text not null, project text not null, type text not null default 'apt',
  city text not null, district text not null default '',
  price numeric not null default 0, area numeric not null default 0,
  status text not null default 'avail' check (status in ('avail','res','sold')),
  lead_id uuid references leads(id) on delete set null,
  deal_id uuid,
  created_at timestamptz not null default now()
);
create table deals (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  lead_id uuid references leads(id) on delete set null,
  property_id uuid references properties(id) on delete set null,
  value numeric not null default 0,
  stage text not null default 'new' check (stage in ('new','contact','view','nego','offer','contract','won','lost')),
  broker_id uuid references profiles(id) on delete set null,
  follow_date date not null default current_date,
  closed_month text,
  created_at timestamptz not null default now()
);
alter table properties add constraint properties_deal_fk foreign key (deal_id) references deals(id) on delete set null;
create table commissions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  deal_id uuid not null unique references deals(id) on delete cascade,
  rate numeric not null, company_pct numeric not null, total numeric not null,
  splits jsonb not null default '[]',   -- [{b: profile uuid, pct, status: due|paid, log:[{d,s}]}]
  created_at timestamptz not null default now()
);
create table activities (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references companies(id) on delete cascade,
  type text not null default 'call' check (type in ('call','visit','meet')),
  title text not null, lead_id uuid references leads(id) on delete set null,
  due_date date not null, due_time text not null default '10:00',
  done boolean not null default false, notes jsonb not null default '[]',
  created_at timestamptz not null default now()
);

-- helpers (security definer => no RLS recursion)
create or replace function my_company() returns uuid language sql stable security definer set search_path = public
  as $$ select company_id from profiles where id = auth.uid() and active $$;
create or replace function my_role() returns text language sql stable security definer set search_path = public
  as $$ select role from profiles where id = auth.uid() and active $$;

-- new auth user => join invited company, or create a company and become its admin
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare inv invitations%rowtype; cid uuid; cname text := coalesce(new.raw_user_meta_data->>'company_name','');
begin
  select * into inv from invitations where lower(email) = lower(new.email) order by created_at limit 1;
  if found then
    insert into profiles (id, company_id, full_name, email, role)
    values (new.id, inv.company_id, coalesce(nullif(new.raw_user_meta_data->>'full_name',''), inv.full_name), new.email, inv.role);
    delete from invitations where id = inv.id;
  elsif cname <> '' then
    insert into companies (name_ar, name_en) values (cname, cname) returning id into cid;
    insert into profiles (id, company_id, full_name, email, role)
    values (new.id, cid, coalesce(new.raw_user_meta_data->>'full_name',''), new.email, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- Row Level Security
alter table companies enable row level security;
alter table profiles enable row level security;
alter table invitations enable row level security;
alter table leads enable row level security;
alter table commissions enable row level security;

create policy companies_s on companies for select using (id = my_company());
create policy companies_u on companies for update using (id = my_company() and my_role() = 'admin') with check (id = my_company());

create policy profiles_s on profiles for select using (company_id = my_company());
create policy profiles_u on profiles for update using (company_id = my_company() and my_role() = 'admin') with check (company_id = my_company());

create policy inv_all on invitations for all using (company_id = my_company() and my_role() = 'admin') with check (company_id = my_company() and my_role() = 'admin');

-- leads: brokers only see/own their own leads
create policy leads_s on leads for select using (company_id = my_company() and (my_role() <> 'broker' or broker_id = auth.uid()));
create policy leads_i on leads for insert with check (company_id = my_company() and my_role() in ('admin','sales','broker') and (my_role() <> 'broker' or broker_id = auth.uid()));
create policy leads_u on leads for update using (company_id = my_company() and my_role() in ('admin','sales','broker') and (my_role() <> 'broker' or broker_id = auth.uid()))
  with check (company_id = my_company() and (my_role() <> 'broker' or broker_id = auth.uid()));
create policy leads_d on leads for delete using (company_id = my_company() and my_role() in ('admin','sales'));

do $$ declare t text; begin
  foreach t in array array['properties','deals','activities'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy %I on %I for select using (company_id = my_company())', t||'_s', t);
    execute format('create policy %I on %I for insert with check (company_id = my_company() and my_role() in (''admin'',''sales'',''broker''))', t||'_i', t);
    execute format('create policy %I on %I for update using (company_id = my_company() and my_role() in (''admin'',''sales'',''broker'')) with check (company_id = my_company())', t||'_u', t);
    execute format('create policy %I on %I for delete using (company_id = my_company() and my_role() in (''admin'',''sales''))', t||'_d', t);
  end loop;
end $$;
create policy activities_d_broker on activities for delete using (company_id = my_company() and my_role() = 'broker');

-- commissions: everyone in the company reads; sales/brokers create on deal close; admin/accountant change status & splits
create policy comm_s on commissions for select using (company_id = my_company());
create policy comm_i on commissions for insert with check (company_id = my_company() and my_role() in ('admin','sales','broker'));
create policy comm_u on commissions for update using (company_id = my_company() and my_role() in ('admin','acct')) with check (company_id = my_company());
create policy comm_d on commissions for delete using (company_id = my_company() and my_role() in ('admin','sales','broker'));
