# Aqarna CRM — Saudi Real Estate CRM (Vite + React + TypeScript + Supabase)

## 1) Supabase
1. Create a project at supabase.com.
2. SQL Editor → paste and run `supabase/schema.sql` (tables, RLS policies, signup trigger).
3. Authentication → Providers → Email: enabled. (Recommended: keep "Confirm email" ON in production.)
4. Project Settings → API: copy **Project URL** and **anon public key**.

## 2) Run locally
```bash
npm install
cp .env.example .env      # fill VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev
```
Register a company from the login screen (first user becomes company admin).
Add employees from "Users & Permissions": the employee then signs up with the same email
(company name left empty) and joins your company with the assigned role.

## 3) GitHub
```bash
git init && git add . && git commit -m "Aqarna CRM"
git branch -M main
git remote add origin https://github.com/<you>/aqarna-crm.git
git push -u origin main
```

## 4) Vercel
Import the repo → Framework preset: Vite → add env vars `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`
(Production, Preview, Development) → Deploy. `vercel.json` already handles SPA rewrites.
Then add the Vercel URL in Supabase → Authentication → URL Configuration (Site URL / Redirect URLs).
